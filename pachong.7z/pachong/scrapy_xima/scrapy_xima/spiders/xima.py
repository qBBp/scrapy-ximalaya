import scrapy
import time
import re
from scrapy_xima.items import ScrapyXimaItem
from selenium import webdriver



class XimaSpider(scrapy.Spider):
    name = "xima"
    allowed_domains = ["www.ximalaya.com"]
    start_urls = ['https://www.ximalaya.com/category/a9_b4434/']

    base_url = 'https://www.ximalaya.com/category/a9_b4434/'

    def parse(self, response):
       #pipeline下载数据
       #items定义数据结构
       # src = //ul[@class = ''ZV'']/li//img/@src
       # name = //ul[@class = ''ZV'']/li//a[''@class = album-title line-2 lg bold T_G'']/@title
       # src = //ul[@class="_ZV"]/li[@class="_ZV"]//img/@src
       #//ul[@class="_ZV"]/li[@class="_ZV"]/div/div/a/img/@src
       # name = //ul[@class="_ZV"]/li[@class="_ZV"]//a/@title




       # browser = webdriver.Chrome()  # 使用Chrome浏览器
       # browser.get("https://www.ximalaya.com/category/a9_b4434/")
       # time.sleep(3)

       li_list = response.xpath('//ul[@class="_ZV"]/li[@class="_ZV"]')
       # li_list = response.xpath('//div[@class="albums _ZV"]')           ##二级页面


       for li in li_list:
           # src = li.xpath('.//div/div/a/img/@src').extract_first()
           name = li.xpath('.//a/@title').extract_first()
           href = li.xpath('.//a[1]/@href').extract_first()


           #第二页地址
           url = 'https://www.ximalaya.com'+href
           yield scrapy.Request(url=url,callback=self.parse_second,meta={'name':name})

           time.sleep(2)
           # book = ScrapyXimaItem(src='https://www.ximalaya.com'+src,name=name,href='https://www.ximalaya.com'+href)
           book = ScrapyXimaItem( name=name,href='https://www.ximalaya.com' + href)
           yield book
       # browser.quit()
       #
       # if self.page<100:
       #      self.page = self.page + 1
       #      url = self.base_url + 'p' + str(self.page) +'/'
       #
       #      yield scrapy.

    def parse_second(self, response):
        # 模拟浏览器
       src = response.xpath('/article//img[@data-key="0"]/@src') .extract_first()
       text = response.xpath('//div//article//p') .extract_first()
       name = response.meta['name'].extract_first()

       # print(name,src,text)
       # second = ScrapyXimaItem(src='https://imagev2.xmcdn.com' + src, name=name,text=text)
       # yield second

       # 一级页面
       # //div[@class="albums _ZV"]//a[1]/@title  题目
       # //div[@class="albums _ZV"]//a/img/@src   图片

       # 二级页面
       # //div[@class="albums _ZV"]//a[1]/@href  链接
       #
       # a_list = response.xpath('//div[@class="albums _ZV"]')

       # for a in a_list:
       #     name = a.xpath('.//a[1]/@title').extract_first()
       #     src = a.xpath('.//a[1]/img/@src').extract_first()
       #     href = a.xpath('.//a[1]/@href').extract_first()
       #     print(name, src, href)
    pass








pass

