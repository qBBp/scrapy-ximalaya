import scrapy
import time
import re

import self as self
from scrapy_xima.items import ScrapyXimaItem
from selenium import webdriver



class XimaSpider(scrapy.Spider):
    name = "xima1"
    allowed_domains = ["www.ximalaya.com"]
    start_urls = ['https://www.ximalaya.com/category/a9_b4434/']

    base_url = 'https://www.ximalaya.com/category/a9_b4434/p'
    page = 1

    def parse(self, response):
       #pipeline下载数据
       #items定义数据结构
       #href =  //li//a[@class="album-title line-2 lg bold T_G"]/@href
       #title = //li//a[@class="album-title line-2 lg bold T_G"]/@title

       li_list = response.xpath('//li//a[@class="album-title line-2 lg bold T_G"]')



       for li in li_list:
           # src = li.xpath('.//div/div/a/img/@src').extract_first()
            name = li.xpath('./@title').extract_first()
            href = li.xpath('./@href').extract_first()
            #第二页网址
            url = href
            # print(url)
            yield scrapy.Request(url=url,callback=self.parse_second,meta={'name':name})
            time.sleep(0.5)



    def parse_second(self, response):
        # 模拟浏览器
       # src = response.xpath('/article//img[@data-key="0"]/@src') .extract_first()
       # text = response.xpath('//div//article//p') .extract_first()
        name = response.meta['name']
        src = response.xpath('//div//img[@class="img v_w"]/@src').extract_first()  #封面图片
        src_ = response.xpath('//article//img/@src')                          #简介图片
        text = response.xpath('//div//article//p').extract_first()                 # 简介

        audio = ScrapyXimaItem(src=src,name=name)

        yield audio
        print(src_)


        if self.page < 100:
            self.page = self.page + 1

            url = self.base_url + str(self.page)+'/'
            yield scrapy.Request(url=url,callback=self.parse)









pass